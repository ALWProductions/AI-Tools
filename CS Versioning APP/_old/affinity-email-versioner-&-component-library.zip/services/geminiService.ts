
import { GoogleGenAI, Type } from "@google/genai";
import { EmailSection, AffinityGroup } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeEmailStructure(html: string): Promise<EmailSection[]> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following Table-based Email HTML. Identify and label sections based on these specific HTML comments: 
    - <!-- View in Browser -->
    - <!-- 2 Column - Logo and Button -->
    - <!-- Header Image -->
    - <!-- Signature -->
    - <!-- Footer -->
    
    Categorize all other content blocks as "Story Content".
    Return a JSON array of sections with: label, the raw HTML content, and isPreserved (true for structural comments listed above).

    HTML:
    ${html}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            label: { type: Type.STRING },
            content: { type: Type.STRING },
            isPreserved: { type: Type.BOOLEAN }
          },
          required: ["label", "content", "isPreserved"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse AI response for email structure", e);
    return [];
  }
}

export async function mergeEmailContent(
  sourceSections: EmailSection[],
  targetSections: EmailSection[],
  sourceHead: string,
  affinityGroup: AffinityGroup
): Promise<string> {
  const sourceContent = sourceSections.filter(s => !s.label.toLowerCase().includes('footer') && !s.label.toLowerCase().includes('logo') && !s.label.toLowerCase().includes('browser') && !s.label.toLowerCase().includes('header')).map(s => s.content).join('\n');
  
  const brandingRules = {
    [AffinityGroup.CHI]: { link: "#0171c2", btn: "#64a000" },
    [AffinityGroup.DIGNITY]: { link: "#0171c2", btn: "#0171C2" },
    [AffinityGroup.MOUNTAIN]: { link: "#70457D", btn: "#70457D" }
  };
  const rules = brandingRules[affinityGroup];

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Task: Merge email content into a target template structure.
    
    1. HEAD: Strictly use this inside <head>: ${sourceHead}
    2. TARGET STRUCTURE: ${JSON.stringify(targetSections)}
    3. SOURCE STORY: ${sourceContent}
    
    INSTRUCTIONS:
    - Return a complete HTML document.
    - KEEP the target's preserved sections (Footer, Logo, Browser, Signature) exactly.
    - REPLACE target's "Story Content" or body with the SOURCE STORY.
    - BRANDING: Apply color: ${rules.link} to links and background-color: ${rules.btn} to buttons inside the STORY content only.
    - CRITICAL: Output ONLY raw HTML. No markdown, no triple backticks, no JSON, no explanations. Just start with <!DOCTYPE html>.`,
    config: {
      thinkingConfig: { thinkingBudget: 15000 }
    }
  });

  // Aggressive cleanup for any accidental markdown
  let cleaned = response.text || "";
  cleaned = cleaned.replace(/```html/gi, '').replace(/```/g, '').trim();
  return cleaned;
}

export async function generateAltText(imageSrc: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Briefly describe this image for a healthcare foundation email alt-text: ${imageSrc}. Plain text only.`
  });
  return response.text?.trim() || "Email image";
}
