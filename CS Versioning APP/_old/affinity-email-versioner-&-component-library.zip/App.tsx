
import React, { useState, useEffect, useCallback } from 'react';
import { AffinityGroup, EmailLink, EmailImage, EmailSection, Foundation, ComponentType, EmailComponent } from './types';
import AffinityBrandToggle from './components/AffinityBrandToggle';
import FileUploadZone from './components/FileUploadZone';
import { analyzeEmailStructure, generateAltText, mergeEmailContent } from './services/geminiService';
import { 
  Settings2, 
  Link as LinkIcon, 
  Image as ImageIcon, 
  Code as CodeIcon, 
  Download, 
  ArrowRight,
  Loader2,
  Trash2,
  RotateCcw,
  Library,
  PlusCircle,
  FolderOpen,
  Save,
  CheckCircle
} from 'lucide-react';

const App: React.FC = () => {
  const [sourceHtml, setSourceHtml] = useState('');
  const [targetHtml, setTargetHtml] = useState('');
  const [affinityGroup, setAffinityGroup] = useState<AffinityGroup>(AffinityGroup.CHI);
  
  // Library State
  const [foundations, setFoundations] = useState<Foundation[]>(() => {
    const saved = localStorage.getItem('email_foundations_v2');
    return saved ? JSON.parse(saved) : [];
  });
  const [activeFoundation, setActiveFoundation] = useState<Foundation | null>(null);

  const [links, setLinks] = useState<EmailLink[]>([]);
  const [images, setImages] = useState<EmailImage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<'upload' | 'configure' | 'preview' | 'library'>('upload');
  const [finalHtml, setFinalHtml] = useState('');

  useEffect(() => {
    localStorage.setItem('email_foundations_v2', JSON.stringify(foundations));
  }, [foundations]);

  const parseResources = useCallback((html: string) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    // Links
    const anchorTags = Array.from(doc.querySelectorAll('a'));
    const extractedLinks: EmailLink[] = anchorTags.map((a, i) => ({
      id: `link-${i}`,
      originalUrl: a.getAttribute('href') || '',
      isRemoved: false,
      text: a.innerText.trim() || 'Link Text'
    })).filter((l) => l.originalUrl && l.originalUrl !== '#' && l.originalUrl.startsWith('http'))
       .filter((l, i, self) => i === self.findIndex((t) => t.originalUrl === l.originalUrl));

    // Images
    const imgTags = Array.from(doc.querySelectorAll('img'));
    const extractedImages: EmailImage[] = imgTags.map((img, i) => ({
      id: `img-${i}`,
      originalSrc: img.getAttribute('src') || '',
      newSrc: img.getAttribute('src') || '',
      originalAlt: img.getAttribute('alt') || '',
      newAlt: img.getAttribute('alt') || '',
      keepOriginal: true
    })).filter(img => img.originalSrc);

    setLinks(extractedLinks);
    setImages(extractedImages);
  }, []);

  const handleProcess = async () => {
    if (!sourceHtml || !targetHtml) return;
    setIsProcessing(true);
    try {
      // 1. Precise Head Isolation
      const headMatch = sourceHtml.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
      const sourceHead = headMatch ? headMatch[1] : '';

      // 2. AI Structure Analysis
      const sourceSections = await analyzeEmailStructure(sourceHtml);
      const targetSections = await analyzeEmailStructure(targetHtml);

      // 3. AI Merge & Injection
      let merged = await mergeEmailContent(sourceSections, targetSections, sourceHead, affinityGroup);
      
      // Sanitization: Ensure no markdown artifacts
      merged = merged.replace(/```html/g, '').replace(/```/g, '').trim();

      // 4. Link & Image Substitutions
      let processed = merged;
      links.forEach(link => {
        if (link.isRemoved) {
          const escapedUrl = link.originalUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const regex = new RegExp(`href=["']${escapedUrl}["']`, 'g');
          processed = processed.replace(regex, 'href="#"');
        }
      });

      images.forEach(img => {
        const escapedSrc = img.originalSrc.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        if (!img.keepOriginal && img.newSrc) {
          const srcRegex = new RegExp(`src=["']${escapedSrc}["']`, 'g');
          processed = processed.replace(srcRegex, `src="${img.newSrc}"`);
        }
        if (img.newAlt !== img.originalAlt) {
          const imgTagRegex = new RegExp(`(<img[^>]*src=["']${escapedSrc}["'][^>]*alt=["'])([^"']*)(["'][^>]*>)`, 'g');
          processed = processed.replace(imgTagRegex, `$1${img.newAlt}$3`);
        }
      });

      setFinalHtml(processed);
      setStep('configure');
    } catch (err) {
      console.error(err);
      alert("Versioning failed. Please check your HTML files.");
    } finally {
      setIsProcessing(false);
    }
  };

  const captureToLibrary = async (html: string) => {
    if (!html) return;
    setIsProcessing(true);
    try {
      const sections = await analyzeEmailStructure(html);
      const headMatch = html.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
      
      const newComponents: EmailComponent[] = sections.map(s => ({
        id: Math.random().toString(36).substr(2, 9),
        type: s.label.toLowerCase().includes('footer') ? ComponentType.FOOTER : 
              s.label.toLowerCase().includes('signature') ? ComponentType.SIGNATURE :
              s.label.toLowerCase().includes('logo') ? ComponentType.LOGO_NAV : ComponentType.CALLOUT,
        label: s.label,
        content: s.content
      }));

      if (headMatch) {
        newComponents.push({
          id: 'head-comp',
          type: ComponentType.HEAD,
          label: 'Master Head Styles',
          content: headMatch[1]
        });
      }

      const name = prompt("Name this Foundation (e.g. Dignity St. Rose):");
      if (name) {
        const newFoundation: Foundation = {
          id: Math.random().toString(36).substr(2, 9),
          name,
          region: affinityGroup,
          components: newComponents
        };
        setFoundations([...foundations, newFoundation]);
        alert(`Foundation "${name}" saved to library.`);
      }
    } catch (e) {
      alert("Capture error.");
    } finally {
      setIsProcessing(false);
    }
  };

  const loadFromLibrary = (foundation: Foundation) => {
    const head = foundation.components.find(c => c.type === ComponentType.HEAD)?.content || '';
    const footer = foundation.components.find(c => c.type === ComponentType.FOOTER)?.content || '';
    const logo = foundation.components.find(c => c.type === ComponentType.LOGO_NAV)?.content || '';
    
    const shell = `<!DOCTYPE html>
<html lang="en">
<head>${head}</head>
<body>
  <div align="center">
    <table border="0" cellpadding="0" cellspacing="0" width="600">
      <tr><td><!-- 2 Column - Logo and Button -->${logo}<!-- 2 Column - Logo and Button END --></td></tr>
      <tr><td height="100"><!-- Story Content --> STORY_PLACEHOLDER <!-- Story Content END --></td></tr>
      <tr><td><!-- Footer START -->${footer}<!-- Footer END --></td></tr>
    </table>
  </div>
</body>
</html>`;

    setTargetHtml(shell);
    setActiveFoundation(foundation);
    setAffinityGroup(foundation.region);
    setStep('upload');
  };

  const downloadHtml = () => {
    const blob = new Blob([finalHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `versioned_${affinityGroup.toLowerCase()}_${new Date().getTime()}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <header className="bg-white border-b border-slate-200 px-8 py-4 sticky top-0 z-50 shadow-sm flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="bg-slate-900 p-2 rounded-lg">
            <Settings2 className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">Affinity Versioner</h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em]">Regional Branding Logic</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={() => setStep('library')}
            className={`px-4 py-2 rounded-lg flex items-center gap-2 font-semibold text-sm transition-all ${step === 'library' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <Library className="w-4 h-4" /> Component Library
          </button>
          
          {(step !== 'upload' || targetHtml) && (
            <button 
              onClick={() => { setStep('upload'); setActiveFoundation(null); setTargetHtml(''); setSourceHtml(''); }} 
              className="px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-lg flex items-center gap-2 text-sm font-semibold"
            >
              <RotateCcw className="w-4 h-4" /> Reset Tool
            </button>
          )}
          
          {step === 'configure' && (
            <button 
              onClick={() => setStep('preview')} 
              className="px-6 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 font-bold text-sm shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
            >
              Spot Check <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-8 py-10">
        {step === 'library' && (
          <div className="animate-in fade-in duration-500">
            <div className="flex justify-between items-end mb-8">
              <div>
                <h2 className="text-2xl font-bold">Foundation Library</h2>
                <p className="text-slate-500 text-sm">Stored locally in your browser cache.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[AffinityGroup.CHI, AffinityGroup.DIGNITY, AffinityGroup.MOUNTAIN].map(group => (
                <div key={group} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col">
                  <div className={`px-4 py-3 text-white font-bold text-xs tracking-widest ${
                    group === 'CHI' ? 'bg-blue-600' : group === 'DIGNITY' ? 'bg-orange-500' : 'bg-purple-700'
                  }`}>
                    {group} REGION
                  </div>
                  <div className="p-4 space-y-2 flex-1 min-h-[120px]">
                    {foundations.filter(f => f.region === group).length === 0 ? (
                      <p className="text-[10px] text-slate-400 italic text-center py-8">No saved foundations.</p>
                    ) : (
                      foundations.filter(f => f.region === group).map(f => (
                        <div key={f.id} className="group p-3 border border-slate-100 rounded-xl hover:border-blue-200 hover:bg-blue-50 transition-all flex justify-between items-center cursor-pointer" onClick={() => loadFromLibrary(f)}>
                          <div className="flex items-center gap-2 overflow-hidden">
                            <FolderOpen className="w-4 h-4 text-slate-400 group-hover:text-blue-500 flex-shrink-0" />
                            <span className="font-bold text-sm text-slate-700 truncate">{f.name}</span>
                          </div>
                          <button onClick={(e) => {
                            e.stopPropagation();
                            setFoundations(foundations.filter(x => x.id !== f.id));
                          }} className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-500">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 'upload' && (
          <div className="animate-in fade-in duration-500">
            <div className="mb-10">
              <h2 className="text-xl font-bold mb-4">1. Select Affinity Group</h2>
              <AffinityBrandToggle selected={affinityGroup} onChange={setAffinityGroup} />
            </div>

            <div className="mb-10">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">2. Upload Files</h2>
                {activeFoundation && (
                  <div className="flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-[10px] font-black uppercase border border-green-200">
                    <CheckCircle className="w-3 h-3" /> Source: {activeFoundation.name}
                  </div>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <FileUploadZone 
                  label="Versioned Email"
                  description="Upload the email with the content you want to copy."
                  onFileSelect={(content) => { setSourceHtml(content); if (content) parseResources(content); }}
                  hasFile={!!sourceHtml}
                />
                <div className="space-y-4">
                  <FileUploadZone 
                    label="Target Template"
                    description="Upload the foundation template or load from library."
                    onFileSelect={setTargetHtml}
                    hasFile={!!targetHtml}
                  />
                  {targetHtml && !activeFoundation && (
                    <button 
                      onClick={() => captureToLibrary(targetHtml)}
                      className="w-full py-3 bg-white text-slate-700 rounded-xl font-bold text-xs border border-slate-200 hover:bg-slate-50 flex items-center justify-center gap-2 transition-all shadow-sm"
                    >
                      <Save className="w-4 h-4 text-blue-500" /> Save Template to Library
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-center mt-12">
              <button
                disabled={!sourceHtml || !targetHtml || isProcessing}
                onClick={handleProcess}
                className="px-16 py-4 bg-slate-900 text-white rounded-2xl font-black text-lg flex items-center gap-4 disabled:opacity-50 shadow-2xl hover:scale-105 active:scale-95 transition-all"
              >
                {isProcessing ? <><Loader2 className="w-6 h-6 animate-spin" /> Analyzing Content...</> : <><ArrowRight className="w-6 h-6" /> Process Versioning</>}
              </button>
            </div>
          </div>
        )}

        {step === 'configure' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <section className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-blue-500" />
                <h3 className="font-bold text-sm uppercase tracking-widest text-slate-800">Review Source Links</h3>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {links.map((link, idx) => (
                    <div key={link.id} className={`p-3 rounded-xl border flex justify-between items-center transition-all ${link.isRemoved ? 'bg-red-50 border-red-100' : 'bg-white border-slate-100'}`}>
                      <div className="overflow-hidden">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5 truncate">{link.text}</p>
                        <p className={`text-xs truncate font-mono ${link.isRemoved ? 'text-red-400' : 'text-slate-600'}`}>{link.isRemoved ? '#' : link.originalUrl}</p>
                      </div>
                      <button onClick={() => {
                        const newLinks = [...links];
                        newLinks[idx].isRemoved = !newLinks[idx].isRemoved;
                        setLinks(newLinks);
                      }} className={`p-2 rounded-lg transition-colors ${link.isRemoved ? 'bg-red-500 text-white' : 'bg-slate-100 text-slate-400 hover:text-red-500'}`}>
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            <section className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-purple-500" />
                <h3 className="font-bold text-sm uppercase tracking-widest text-slate-800">Review Assets</h3>
              </div>
              <div className="divide-y divide-slate-100">
                {images.map((img, idx) => (
                  <div key={img.id} className="p-6 flex flex-col md:flex-row gap-6">
                    <div className="w-24 h-24 bg-slate-50 rounded-lg flex-shrink-0 flex items-center justify-center overflow-hidden border border-slate-100">
                      <img src={img.originalSrc} className="max-w-full max-h-full object-contain" />
                    </div>
                    <div className="flex-1 space-y-4">
                      <div className="flex items-end gap-4">
                        <div className="flex-1">
                          <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Image Source URL</label>
                          <input type="text" className="w-full mt-1 p-2 text-xs bg-slate-50 border border-slate-200 rounded-md font-mono" value={img.newSrc} onChange={(e) => {
                            const newImages = [...images];
                            newImages[idx].newSrc = e.target.value;
                            newImages[idx].keepOriginal = e.target.value === img.originalSrc;
                            setImages(newImages);
                          }} />
                        </div>
                        <div className="flex items-center gap-2 pb-2">
                          <input type="checkbox" checked={img.keepOriginal} onChange={() => {
                            const newImages = [...images];
                            newImages[idx].keepOriginal = !newImages[idx].keepOriginal;
                            if (newImages[idx].keepOriginal) newImages[idx].newSrc = img.originalSrc;
                            setImages(newImages);
                          }} className="w-4 h-4 rounded" />
                          <label className="text-[9px] font-black text-slate-500 uppercase">Keep</label>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Alt-Text Description</label>
                          <button onClick={async () => {
                            const suggestion = await generateAltText(img.originalSrc);
                            const newImages = [...images];
                            newImages[idx].newAlt = suggestion;
                            setImages(newImages);
                          }} className="text-[8px] font-black bg-blue-50 text-blue-600 px-2 py-0.5 rounded border border-blue-100 uppercase">Suggest with AI</button>
                        </div>
                        <textarea className="w-full p-2 text-xs border border-slate-200 rounded-md h-12 resize-none" value={img.newAlt} onChange={(e) => {
                          const newImages = [...images];
                          newImages[idx].newAlt = e.target.value;
                          setImages(newImages);
                        }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {step === 'preview' && (
          <div className="animate-in slide-in-from-bottom-4 duration-500 h-full flex flex-col">
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xl flex flex-col h-[750px]">
              <div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CodeIcon className="w-4 h-4 text-slate-600" />
                  <h3 className="font-bold text-sm tracking-widest uppercase">Spot Check Engine</h3>
                </div>
                <button onClick={downloadHtml} className="px-6 py-2 bg-slate-900 text-white rounded-lg flex items-center gap-2 font-black text-xs hover:bg-black transition-all shadow-lg shadow-slate-200">
                  <Download className="w-4 h-4" /> Download Production HTML
                </button>
              </div>
              
              <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 overflow-hidden">
                {/* Code Preview - Strictly scrollable, NO wrapping */}
                <div className="border-r border-slate-200 flex flex-col overflow-hidden bg-slate-900">
                  <div className="bg-slate-800 text-slate-400 px-4 py-2 text-[9px] font-black uppercase tracking-widest border-b border-slate-700">HTML Source (No Wrap)</div>
                  <div className="flex-1 overflow-auto p-6 scrollbar-thin scrollbar-thumb-slate-700">
                    <pre className="text-emerald-400 font-mono text-[11px] leading-relaxed whitespace-pre min-w-max">
                      <code>{finalHtml}</code>
                    </pre>
                  </div>
                </div>
                
                {/* Visual Preview */}
                <div className="flex flex-col bg-slate-100 overflow-hidden">
                  <div className="bg-white text-slate-400 px-4 py-2 text-[9px] font-black uppercase tracking-widest border-b border-slate-200">Visual Rendering</div>
                  <iframe 
                    title="Live Preview"
                    srcDoc={finalHtml}
                    className="flex-1 w-full bg-white"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
