
export enum AffinityGroup {
  CHI = 'CHI',
  DIGNITY = 'DIGNITY',
  MOUNTAIN = 'MOUNTAIN'
}

export enum ComponentType {
  HEAD = 'HEAD',
  HEADER = 'HEADER',
  LOGO_NAV = 'LOGO_NAV',
  CALLOUT = 'CALLOUT',
  SIGNATURE = 'SIGNATURE',
  FOOTER = 'FOOTER'
}

export interface EmailComponent {
  id: string;
  type: ComponentType;
  label: string;
  content: string;
}

export interface Foundation {
  id: string;
  name: string;
  region: AffinityGroup;
  components: EmailComponent[];
}

export interface EmailLink {
  id: string;
  originalUrl: string;
  isRemoved: boolean;
  text: string;
}

export interface EmailImage {
  id: string;
  originalSrc: string;
  newSrc: string;
  originalAlt: string;
  newAlt: string;
  keepOriginal: boolean;
}

export interface EmailSection {
  label: string;
  content: string;
  isPreserved: boolean;
}
